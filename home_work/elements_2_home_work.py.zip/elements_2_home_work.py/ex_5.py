from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from selenium.common.exceptions import TimeoutException, ElementClickInterceptedException


driver = webdriver.Chrome()
driver.maximize_window()
driver.get("https://www.ebay.com/")

driver.find_element(By.CSS_SELECTOR, "#gh-ac").send_keys("tent")
driver.find_element(By.CSS_SELECTOR, ".gh-search-button__label").click()

wait = WebDriverWait(driver, 10)

list_of_tent = []


for page_index in range(10):
    wait.until(EC.presence_of_all_elements_located((By.CSS_SELECTOR,"[class='su-styled-text primary default']")))
    the_tent_title = driver.find_elements(By.CSS_SELECTOR, "[class='s-card s-card--horizontal s-card--dark-solt-links-blue']")

    for tent in the_tent_title:
        tent_text = tent.text
        list_of_tent.append(tent_text)

    print(f"Finished scraping page {page_index + 1}, collected {len(list_of_tent)} items so far.")
    wait.until(EC.presence_of_all_elements_located((By.CSS_SELECTOR,".pagination__next.icon-link")))
    driver.find_element(By.CSS_SELECTOR, ".pagination__next.icon-link").click()


for item in list_of_tent:
    print(item,"\n","*" *10)